package structuresAlgebriques.fonction;

public interface ModuleMonoideAdditif<T> extends ModuleSemiGroupeAdditif<T>, ModuleUnifereAddition<T> {
}
