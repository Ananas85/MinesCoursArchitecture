package data.phrase;

public class PhraseTropLongue extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

}
