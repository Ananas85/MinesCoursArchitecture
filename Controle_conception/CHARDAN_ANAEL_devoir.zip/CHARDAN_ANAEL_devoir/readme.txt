
CHARDAN ANAEL

1. Mot est juste une hierarchie d'heritage
Texte et phrase sont des composites

J'ai utilise un singleton pour le store parce que il n'est pas sense etre multiple il sert vraiment de registre de phrase