package structuresAlgebriques.objet;

public interface SemiGroupeAdditif<T> {
    T somme( T x );
}
