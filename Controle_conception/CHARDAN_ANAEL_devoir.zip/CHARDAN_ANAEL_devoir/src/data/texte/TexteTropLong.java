package data.texte;

public class TexteTropLong extends Exception {

    private static final long serialVersionUID = 1L;
}
