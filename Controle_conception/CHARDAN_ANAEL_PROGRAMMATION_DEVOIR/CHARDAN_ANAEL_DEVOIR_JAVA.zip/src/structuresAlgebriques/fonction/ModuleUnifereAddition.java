package structuresAlgebriques.fonction;

public interface ModuleUnifereAddition<T> {
    T zero();
}
