package data.phrase;

/**
 * Interface phrase
 */
public interface IPhrase {

    /**
     * Connaitre la taille de la phrase
     */
    public int getSize();

    @Override
    public String toString();
}
