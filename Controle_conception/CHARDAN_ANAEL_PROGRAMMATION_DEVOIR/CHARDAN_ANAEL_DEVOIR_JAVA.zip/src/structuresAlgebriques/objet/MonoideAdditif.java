package structuresAlgebriques.objet;

public interface MonoideAdditif<T> extends SemiGroupeAdditif<T>, UnifereAddition<T> {
}
