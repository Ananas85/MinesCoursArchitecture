package structuresAlgebriques.objet;

public interface UnifereAddition<T> {
    T zero();
}
