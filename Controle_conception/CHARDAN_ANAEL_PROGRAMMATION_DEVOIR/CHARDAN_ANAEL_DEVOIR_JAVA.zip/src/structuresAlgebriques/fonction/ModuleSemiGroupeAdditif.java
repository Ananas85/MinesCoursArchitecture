package structuresAlgebriques.fonction;

public interface ModuleSemiGroupeAdditif<T> {
    T somme( T x, T y );
}
