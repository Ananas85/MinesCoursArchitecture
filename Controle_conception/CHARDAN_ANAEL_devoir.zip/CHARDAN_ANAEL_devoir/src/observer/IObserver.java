package observer;

public interface IObserver {

    void update();
}

